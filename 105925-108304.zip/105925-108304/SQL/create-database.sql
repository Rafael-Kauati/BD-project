--Apenas para testes na base de dados local
--N�o utiliz�vel DB das aulas

CREATE DATABASE [Routine View]
GO
