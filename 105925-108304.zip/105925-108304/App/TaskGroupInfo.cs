﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Routine_View_Forms
{
    public class TaskGroupInfo
    {
        public string Title { get; set; }
        public int Code { get; set; }
        public string isFinished { get; set; }
        public string criteria { get; set; }
    }
}
